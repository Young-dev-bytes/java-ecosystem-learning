export const searchItems = async (term: string, size: number = 5) => {};
