export const deserialize = (item: { [key: string]: string }) => {};
