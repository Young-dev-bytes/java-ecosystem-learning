export const createBid = async () => {};

export const getBidHistory = async (itemId: string, offset = 0, count = 10) => {
	return [];
};
