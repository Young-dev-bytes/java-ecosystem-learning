export const pageCacheKey = (id: string) => `pagecache#${id}`;
