<script lang="ts">
	export let href: string;
	export let child: string;
</script>

<a {href} class="text-indigo-600 hover:text-indigo-900">{child}</a>
