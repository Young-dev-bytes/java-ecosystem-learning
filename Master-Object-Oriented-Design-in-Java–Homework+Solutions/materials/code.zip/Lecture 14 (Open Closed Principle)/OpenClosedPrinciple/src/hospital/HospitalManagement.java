package hospital;


public class HospitalManagement {

	public void callUpon(Employee employee) {

		employee.performDuties();

	}

}
