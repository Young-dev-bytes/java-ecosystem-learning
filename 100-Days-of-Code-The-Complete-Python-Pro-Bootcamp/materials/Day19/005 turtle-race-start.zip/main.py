from turtle import Turtle, Screen

tim = Turtle()
screen = Screen()


screen.exitonclick()