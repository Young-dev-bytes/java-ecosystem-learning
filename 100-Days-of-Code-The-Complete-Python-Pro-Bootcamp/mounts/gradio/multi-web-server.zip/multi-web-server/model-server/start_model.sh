python3 model_work.py \
--model-path /root \
--device cuda:0 --host 127.0.0.1 --register-host 127.0.0.1 \
--port 21005 --controller-address http://127.0.0.1:21001 \
--model-name qwen-7b --model-type self_develop --tab ''

# python3 model_work.py --model-path /root --device cuda:0 --host 127.0.0.1 --register-host 127.0.0.1 --port 21002 --controller-address http://127.0.0.1:21001 --model-name qwen-7b --model-type self_develop --tab ''